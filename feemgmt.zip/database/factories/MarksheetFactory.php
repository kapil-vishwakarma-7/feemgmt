<?php

use Faker\Generator as Faker;

$factory->define(App\Marksheet::class, function (Faker $faker) {
    return [
        //
    ];
});
