<?php

use Faker\Generator as Faker;

$factory->define(App\Enquiry::class, function (Faker $faker) {
    return [
        //
    ];
});
