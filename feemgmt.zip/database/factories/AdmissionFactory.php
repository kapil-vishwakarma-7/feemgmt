<?php

use Faker\Generator as Faker;

$factory->define(App\Admission::class, function (Faker $faker) {
    return [
        //
    ];
});
