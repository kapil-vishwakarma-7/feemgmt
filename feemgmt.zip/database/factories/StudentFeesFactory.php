<?php

use Faker\Generator as Faker;

$factory->define(App\StudentFees::class, function (Faker $faker) {
    return [
        //
    ];
});
