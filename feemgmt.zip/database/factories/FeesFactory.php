<?php

use Faker\Generator as Faker;

$factory->define(App\Fees::class, function (Faker $faker) {
    return [
        //
    ];
});
