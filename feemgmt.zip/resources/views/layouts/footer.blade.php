
 <!--main content end-->
 <footer>
 <section class="" id="main-content">
    <section class="wrapper">
    <div class="row">
         <div class="panel panel-primary text-center">
  <div class="panel-body"><a href="">Ultrasoftacademy</a> Developed by <a href="https://beangate.in/">Beangate IT Solutions Pvt. Ltd.</a>
  </div>
</div>
</div>
    </section>
  </section>
  </footer>
  </section>
  <!-- container section end -->

  <!-- custom form validation script for this page-->
  	