@extends('layouts.header')

@section('body')


    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-files-o"></i> Course Detail</h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="icon_document_alt"></i>Add/Update</li>
              <li><i class="fa fa-files-o"></i>Courses</li>
            </ol>
          </div>

		<div class="row col-md-offset-3">
			<h1>Reports Comming Soon </h1>		
				<a href="{{url('/')}}" class="btn btn-success btn-lg">Back</a>
		</div>
        </div>
      </section>
    </section>    


@stop    
