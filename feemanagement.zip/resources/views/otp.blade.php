<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<label>Otp ............</label>
   <input class="form-control " type="text" name="otpvalue">
   <button type="button" class="btn btn-success">submit</button>
</body>
</html>