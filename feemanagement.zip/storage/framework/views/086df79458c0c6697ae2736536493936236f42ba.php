<div class="table-responsive" id="tab-fee_masters">
<?php if(!is_null($masters)): ?>

								 <table class="table table-hover table-striped">
    <thead>
      <tr>
        <th width="5%">#</th>
        <th width="15%">Fees Type</th>
        <th width="20%">Amount</th>
        <th width="40%">Description</th>
        <th width="20%">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $masters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($e->id); ?></td>
          <td><?php echo e($e->fees_type); ?></td>
          <td><?php echo e($e->amount); ?></td>
          <td><?php echo e($e->description); ?></td>
          <td>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>			
<?php endif; ?>

									</div>
