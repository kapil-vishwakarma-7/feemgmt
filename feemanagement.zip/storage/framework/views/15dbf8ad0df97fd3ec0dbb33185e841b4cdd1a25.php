<?php $__env->startSection('body'); ?>

  <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-files-o"></i> Admission List</h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="/">Home</a></li>
              <li><i class="icon_document_alt"></i>Admission</li>
              <li><i class="fa fa-files-o"></i>Details</li>
            </ol>
          </div>
        </div>  
          
        <section class="panel">
                <header class="panel-heading">
                  Student List
                </header>
                <div class="panel-body">
            <div class="col-md-4">
              <form class="form-validate form-horizontal" id="search-form" >
                   <?php echo e(csrf_field()); ?>

              <label>Enrollment No</label>
  <input type="text" class="form-control" placeholder="Search" name="id">
  <br>
</div>
<div class="col-md-3">
  <label>Academic Year</label>
 <select class="form-control" name="year">
   <option selected disabled hidden value="">Select Year</option>
   <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option><?php echo e($y->ac_year); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>

  <br>
</div>
<div class="col-md-3">
  <label>Courses</label>
  <select class="form-control" id="courses" name="course">

   <option selected disabled hidden value="">Select Course</option>
     <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <br>
</div>
<div class="col-md-2">
  <label>Semester</label>
  <select class="form-control" id="semester" name="semester">
  </select>
  <br>
</div>
<button type="button"  class="btn btn-primary" id="search-btn">search</button>
</form>
<div class="col-md-8">
  
</div>
<br>
 <div id="result">
   <?php echo $__env->make('master_fees_table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
 </div>
 
  </div> 
 </section>      
 
</body>
<script type="text/javascript">
 $("#courses").on('change',function(){
    alert();
   $.ajax({
    url:'/getsemesterlist?id='+$(this).val(),
    type:'get',
    success:function(data){
      alert(data);
      $("#semester").html(data);
      console.log(data);
    },
    error:function(data){
      alert(data);
      console.log(data);
    }
   });
  });
 $("#search-btn").click(function(){
  // alert();
  $.ajax({
    url:'/searchstudent',
    type:'POST',
    data:$("#search-form").serialize(),
    success:function(data){
      $("#result").html(data);
      console.log(data)
      // alert("success")
    },
    error:function(data){
      alert("error")
      console.log(data);
    }
  });
 });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>