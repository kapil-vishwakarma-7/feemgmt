    <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td><?php echo e($enquiry->id); ?> </td>
        <td><?php echo e($enquiry->name); ?> </td>
        <td><?php echo e($enquiry->email); ?> </td>
        <td><?php echo e($enquiry->course->name); ?> </td>
        <td><?php echo e($enquiry->contact); ?> </td>
        <td><?php echo e($enquiry->address); ?> </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   