<div class="col-lg-6">
            <!--Project Activity start-->
            <section class="panel" style="min-height: 300px;">
              <div class="panel-body progress-panel">
                <div class="row">
                  <div class="col-lg-8 task-progress pull-left">
                    <h1>Total Payment</h1>
                  </div>
                 
                </div>
              </div>
              <div class="table-responsive">
              <table class="table table-hover">
                <tbody>
                	<tr>
                	<th>Semester</th>
                	<th>Total Amount</th>

                	<th>Paid Amount</th>
                	                	<th>Due Amount</th>
                      <th>Print</th>
                  </tr>
                  <?php $__currentLoopData = $student->course->semesters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                  	<td><?php echo e($e->name); ?></td>
                  	<td><?php echo e($e->feemasters->where('ac_year',$student->admission_year)->sum('amount')); ?></td>
                  	<td><?php echo e($student->fees->where('semester_id',$e->id)->sum('amount')); ?></td>
                  	<td><?php echo e($e->feemasters->where('ac_year',$student->admission_year)->sum('amount') - $student->fees->where('semester_id',$e->id)->sum('amount')); ?> </td>
                  	<td><i class="fa fa-print"></i></td>
                   </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
              </table>
            </section>
            <!--Project Activity end-->
          </div>
                	   <div class="col-lg-6">
            <!--Project Activity start-->
            <section class="panel" style="min-height: 300px;">
              <div class="panel-body progress-panel">
                <div class="row">
                  <div class="col-lg-8 task-progress pull-left">
                    <h1>Previous Payment History</h1>
                  </div>
                 
                </div>
              </div>
              <div class="table-responsive">
              <table class="table table-hover">
                <tbody> 
                  	<tr>
                    	<th>#</th>
                    	<th>Semester</th>
                    	<th>Amount</th>
                    	<th>Payment Mode</th>
                    	<th>Date</th>
                      <th>Print</th>
                      </tr>
                 <?php $i=1;?>
                 <?php $__currentLoopData = $student->fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                     <tr>
                    	<td><?php echo e($i++); ?></td>
                    	<td><?php echo e($e->semester->name); ?></td>
                    	<td><?php echo e($e->amount); ?></td>
                    	<td><?php echo e($e->payment_mode); ?></td>
                    	<td><?php echo e($e->fee_date); ?></td>
                    	<td><i class="fa fa-print"></i></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
              </table>
          </div>
            </section>
            <!--Project Activity end-->
          </div>