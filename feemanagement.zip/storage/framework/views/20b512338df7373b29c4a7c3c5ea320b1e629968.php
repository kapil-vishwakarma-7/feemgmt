<?php if(!is_null($res)): ?>
<div  id="result">
  <div class="col-md-6">
         <table class="table table-striped">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Id</th>
              <th scope="col">Name</th>
              <th scope="col">Contact</th>
              <th scope="col">Gender</th>
              <th scope="col">Email</th>
              <th scope="col">Father Name</th>
              <th scope="col">Course</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            
            <?php $i=1 ?>
               
            <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"> <?php echo e($i++); ?></th>
              <td><?php echo e($student->student_name); ?></td>
              <td><?php echo e($student->student_contact); ?></td>
              <td><?php echo e($student->gender); ?></td>
              <td><?php echo e($student->email); ?></td>
              <td><?php echo e($student->father_name); ?></td>
              <td><?php echo e($student->course_id); ?></td>
              <td>
                <button class="btn-delete btn btn-info btn-sm" data-id=<?php echo e($student->id); ?> >Delete</button>

                <button data-student_id="<?php echo e($student->id); ?>" data-student_name="<?php echo e($student->student_name); ?>" data-student_email="<?php echo e($student->email); ?>" class="edit-student btn btn-success btn-sm" data-toggle="modal" data-target="#myModal">Edit</button>

              </td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
  </div>
</div>
<?php endif; ?>
 