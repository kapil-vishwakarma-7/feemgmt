 <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th class="success">#</th>
        <th class="success">Name</th>
        <th class="success">Email</th>
        <th class="success">Student Contact</th>
        <th class="success">Father Name</th>
        <th class="success">Course</th>
        <th class="success">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td><?php echo e($admission->id); ?> </td>
        <td><?php echo e($admission->student_name); ?> </td>
        <td><?php echo e($admission->email); ?> </td>
        <td><?php echo e($admission->student_contact); ?> </td>
        <td><?php echo e($admission->father_name); ?> </td>
        <td><?php echo e($admission->course_id); ?> </td>
        <td><div class="dropdown">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="#">View Detail</a></li>
    <li><a href="#">Add Fee</a></li>
    <li><a href="#">Admission Update</a></li>
    <li><a href="#">Fee Update </a></li>
  </ul>
</div></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>