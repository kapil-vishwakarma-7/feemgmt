<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
  <meta name="author" content="GeeksLabs">
  <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 

  <link rel="shortcut icon" href="img/favicon.png">
  <title>MCRPV||Admin </title>
<script src="<?php echo e(url('front/js/jquery-1.8.3.min.js')); ?>"></script> 
  <!-- Bootstrap CSS -->
  <link href="<?php echo e(url('front/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <!-- bootstrap theme -->
  <link href="<?php echo e(url('front/css/bootstrap-theme.css')); ?>" rel="stylesheet">
  <!--external css-->
  <!-- font icon -->
  <link href="<?php echo e(url('front/css/elegant-icons-style.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(url('front/css/font-awesome.min.css')); ?>" rel="stylesheet" />
  <!-- Custom styles -->
  <link href="<?php echo e(url('front/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('front/css/style-responsive.css')); ?>" rel="stylesheet" />

    <style type="text/css">
#image-preview,#image-preview1,#image-preview2{
  width: 200px;
  height: 150px;
  position: relative;
  overflow: hidden;
  background-color: #ffffff;
  color: #ecf0f1;
  border: 2px solid gray;
}
#image-preview input ,#image-preview1 input,#image-preview2 input  {
  line-height: 200px;
  font-size: 200px;
  position: absolute;
  opacity: 0;
  z-index: 10;
  color: green;
}
#image-preview label,#image-preview1 label ,#image-preview2 label{
  position: absolute;
  z-index: 5;
  opacity: 0.8;
  cursor: pointer;
  background-color: #4cd964;
  width: 200px;
  height: 50px;
  font-size: 20px;
  line-height: 50px;
  text-transform: uppercase;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
  text-align: center;
}
 .error {
   color: red;
</style>

</head>

<body>
  <!-- container section start -->
  <section id="container" class="">
    <!--header start-->
    <header class="header dark-bg">
      <div class="toggle-nav">
        <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
      </div>

      <!--logo start-->
      <a href="/" class="logo">MCRPV <span class="lite">Admin</span></a>
      <!--logo end-->

        <div class="nav search-row" id="top_menu">
        <!--  search form start -->
        <ul class="nav top-menu">
          <li>
            <form class="navbar-form">
              <input class="form-control" placeholder="Search" type="text">
            </form>
          </li>
        </ul>
        <!--  search form end -->
      </div>

      <div class="top-nav notification-row">
        <!-- notificatoin dropdown start-->
        <ul class="nav pull-right top-menu">
        
          <!-- task notificatoin start -->
          
          <!-- alert notification end-->
          <!-- user login dropdown start-->
        
<?php if(auth()->guard()->check()): ?>
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                
                            </span>
                            <span class="username"><?php echo e(Auth::user()->name); ?></span>
                            <b class="caret"></b>
                        </a>
            <ul class="dropdown-menu extended logout">
              <div class="log-arrow-up"></div>
              
              <li><a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
              </li>
              <li>
              </li>
            </ul>
          </li>


       <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
         <?php echo csrf_field(); ?>
      </form>
<?php endif; ?>
          <!-- user login dropdown end -->
        </ul>
        <!-- notificatoin dropdown end-->
      </div>
    </header>
    <!--header end-->

    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu">
          <li class="active">
            <a class="" href="/">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="fa fa-cog"></i>
                          <span>Institute</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="<?php echo e(route('institute.index')); ?> ">Add Institute</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="icon_documents_alt"></i>
                          <span> Course</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
             <li><a class="" href="<?php echo e(route('courses.index')); ?> ">Add Courses</a></li>
              
            </ul>
          </li>

          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="fa fa-edit"></i>
                          <span>Enquiry</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="<?php echo e(route('enquiry.index')); ?> ">New Enquiry</a></li>
              <li><a class="" href=" <?php echo e(route('enquiry.create')); ?> ">View Enquiry</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" class="">
                          <i class="fa fa-university"></i>
                          <span>Admission</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            <ul class="sub">
              <li><a class="" href="<?php echo e(route('admission.index')); ?>">New Admission</a></li>
              <li><a class="" href="<?php echo e(route('admission.create')); ?>">Student List</a></li>
              
            </ul>
          </li>
        

          <li >
            <a href="<?php echo e(route('feesmaster.index')); ?>" class="">
                          <i class="fa fa-rupee"></i>
                          <span>Fees Master</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
            
          </li>

          
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
   <?php echo $__env->yieldContent('body'); ?> 




<!-- javascripts -->
  
  <script src="<?php echo e(url('front/js/jquery-ui-1.10.4.min.js')); ?>"></script>
  
  <script type="text/javascript" src="<?php echo e(url('front/js/jquery-ui-1.9.2.custom.min.js')); ?>"></script>
  <!-- bootstrap -->
  <script src="<?php echo e(url('front/js/bootstrap.min.js')); ?>"></script>
  <!-- nice scroll -->
  <script src="<?php echo e(url('front/js/jquery.scrollTo.min.js')); ?>"></script>
  <script src="<?php echo e(url('front/js/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
  <!-- charts scripts -->
  
  <!-- jQuery full calendar -->
    <!--script for this page only-->
    
    <script src="<?php echo e(url('front/js/jquery.rateit.min.js')); ?>"></script>
    <!-- custom select -->
    <script src="<?php echo e(url('front/js/jquery.customSelect.min.js')); ?>"></script>
    

    <!--custome script for all page-->
    <script src="<?php echo e(url('front/js/scripts.js')); ?>"></script>
    <!-- custom script for this page-->
    
    <script src="<?php echo e(url('front/js/jquery.slimscroll.min.js')); ?>"></script>



</section>
</body>
</html>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>