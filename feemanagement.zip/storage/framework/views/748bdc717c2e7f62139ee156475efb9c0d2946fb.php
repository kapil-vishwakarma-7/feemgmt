<?php $__env->startSection('body'); ?>

  <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-files-o"></i> New Enquiry Form</h3>
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="/">Home</a></li>
              <li><i class="icon_document_alt"></i>Enquiry</li>
              <li><i class="fa fa-files-o"></i>Details</li>
            </ol>
          </div>
        </div>        
  <table class="table table-hover content">
    <thead>
      <tr>
        <th>S.no</th>
        <th>Name</th>
        <th>Email</th>
        <th>Course</th>
        <th>Contact</th>
        <th>Address</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td><?php echo e($enquiry->id); ?> </td>
        <td><?php echo e($enquiry->name); ?> </td>
        <td><?php echo e($enquiry->email); ?> </td>
        <td><?php echo e($enquiry->course->name); ?> </td>
        <td><?php echo e($enquiry->contact); ?> </td>
        <td><?php echo e($enquiry->address); ?> </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  <?php echo e($enquiries->links()); ?>

<script type="text/javascript">
  $(document).on('click','.pagination a',function(e){
    e.preventDefault();
    var page=$(this).attr('href').split('page=')[1];
    // console.log($(this).attr('href').split('page='));
    getEnquiry(page);
  });
  function getEnquiry(page){
    $.ajax({
    url:'/enquairyview?page='+page,
    type:'GET',
    }).done(function(data){
      $('.content').html(data);
      location.hash=page;
    });
  }
</script>

</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>