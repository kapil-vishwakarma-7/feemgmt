<?php if(!is_null($res)): ?>
<div  id="result">
  <div class="col-md-12">
         <table class="table table-striped">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Id</th>
              <th scope="col">Name</th>
              <th scope="col">Contact</th>
              <th scope="col">Gender</th>
              <th scope="col">Email</th>
              <th scope="col">Father Name</th>
              <th scope="col">Course</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            
            <?php $i=1 ?>
               
            <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

              
              <td><?php echo e($i++); ?></td>
              <td><?php echo e($student->id); ?></td>
              <td><?php echo e($student->student_name); ?></td>
              <td><?php echo e($student->student_contact); ?></td>
              <td><?php echo e($student->gender); ?></td>
              <td><?php echo e($student->email); ?></td>
              <td><?php echo e($student->father_name); ?></td>
              <td><?php echo e($student->course->name); ?></td>
              <td>
                <div class="dropdown">
                  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action
                  <span class="caret"></span></button>
                  <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('studentdetail',['id'=>$student->id])); ?>">View Detail</a></li>
                    <li><a href="<?php echo e(route('feespay',['id'=>$student->id] )); ?>">Fee Pay</a></li>
                    <li><a href="<?php echo e(route('studentupdate',['id'=>$student->id])); ?>">Update</a></li>
                    
                  </ul>
                </div>

              </td>
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
  </div>
</div>
<?php endif; ?>
 