 <!--main content end-->
    <div class="text-right">
      <div class="credits">
         
          <a href="https://bootstrapmade.com/">Free Bootstrap Templates</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
    </div>
  </section>
  <!-- container section end -->

  <!-- custom form validation script for this page-->
  	