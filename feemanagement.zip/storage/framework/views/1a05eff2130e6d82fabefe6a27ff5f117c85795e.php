         <div class="col-lg-12">
            <!--Project Activity start-->
            <section class="panel">
              <div class="panel-body progress-panel">
                <div class="row">
                  <div class="col-lg-8 task-progress pull-left">
                    <h1>Student Detail</h1>
                  </div>
                 
                </div>
              </div>
              <div class="table-responsive"> 
              <table class="table   table-bordered table-hover">
                <tbody>
                  <tr>
                    <th class="">Student Name</th>
                    <th>Enrollment</th>
                    <th>Admission Yr</th>
                    <th>Contact</th>

                    <th>Total Fees</th>
                    <th>Paid Fees</th>
                    <th>Fees Due</th>    
                  </tr>
                  
                 <tr>
                  <td><?php echo e($student->student_name); ?></td>
                  <td><?php echo e($student->id); ?></td>
                  <td><?php echo e($student->admission_year); ?></td>
                  <td><?php echo e($student->student_contact); ?></td>
                  <td><?php echo e($student->course->feeMaster->where('ac_year',$student->admission_year)->sum('amount')); ?></td>
                  <td><?php echo e($student->fees->sum('amount')); ?></td>
                  <td> <label><?php echo e($student->course->feeMaster->where('ac_year',$student->admission_year)->sum('amount') - $student->fees->sum('amount')); ?></label> </td>
                </tr>
                  
                  
                </tbody>
              </table>
            </section>
            <!--Project Activity end-->
          </div>