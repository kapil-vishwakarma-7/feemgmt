  

  <?php $__env->startSection('body'); ?>

      <!--main content start-->
      <section id="main-content">
        <section class="wrapper">
          <div class="row">
            <div class="col-lg-12">
              <h3 class="page-header"><i class="fa fa-files-o"></i> Student Details</h3>
              <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><i class="icon_document_alt"></i>student</li>
                <li><i class="fa fa-files-o"></i>detail</li>
              </ol>
            </div>
          </div>
 <div class="container">

  <div class="panel panel-default">
    <div class="panel-body">Basic Information</div>
         <div class="row">
                <div class="col-md-3 col-lg-3 " align="center"> <img alt="User Pic" src="http://babyinfoforyou.com/wp-content/uploads/2014/10/avatar-300x300.png" class="img-circle img-responsive"> </div>
            
                <div class=" col-md-9 col-lg-9 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td><b>Name:</b></td>
                        <td>Shubham</td>
                      </tr>
                      <tr>
                      <td><b>Email:</b></td>
                        <td>sv@gmail.com</td>
                      </tr>
                      <tr>
                        <td><b>Phone:</b></td>
                        <td>9898786543</td>
                      </tr>
                    <tr>
                        <td><b>Adhar No. :</b></td>
                        <td>785984265312</td>
                      </tr>
                         <tr>
                             
                        <td><b>Gender:</b></td>
                        <td>Male</td>
                      </tr>
                        <tr>
                        <td><b>DOB:</b></td>
                        <td>26-01-96</td>
                      </tr>
                      <tr>
                        <td><b>Address:</b></td>
                        <td>333 Gopal Nagar Bhopal</td>
                      </tr>
                    
                           
                      </tr>
                     
                    </tbody>
                  </table>
                  
                  
                </div>
              </div>
            </div>


               <div class="panel panel-default">
    <div class="panel-body">Other Information</div>
         <div class="row">
              
            
                <div class=" col-md-12 col-lg-12 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td><b>Father Name:</b></td>
                        <td>Santosh</td>
                      </tr>
                      <tr>
                      <td><b>Father Contact:</b></td>
                        <td>9786756435</td>
                      </tr>
                      <tr>
                        <td><b>Mother name:</b></td>
                        <td>Sarita</td>
                      </tr>
                    <tr>
                       
                           
                      </tr>
                     
                    </tbody>
                  </table>
                  
                  
                </div>
              </div>
  </div>

             <div class="panel panel-default">
    <div class="panel-body">Addmission Information</div>
         <div class="row">
              
            
                <div class=" col-md-12 col-lg-12 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td><b>Addmission Year :</b></td>
                        <td>2014</td>
                      </tr>
                      
                   
                           
                      </tr>
                     
                    </tbody>
                  </table>
                  
                  
                </div>
              </div>
  </div>
             <div class="panel panel-default">
    <div class="panel-body">Previous Year Information</div>
         <div class="row">
              
            
                <div class=" col-md-12 col-lg-12 "> 
                  <table class="table table-user-information">
                    <tbody>
                      <tr>
                        <td><b>Exam:</b></td>
                        <td>dont know</td>
                      </tr>
                      <tr>
                      <td><b>Subject:</b></td>
                        <td>Pata nahi</td>
                      </tr>
                      <tr>
                        <td><b>Board:</b></td>
                        <td>MP Board</td>
                      </tr>
                          <tr>
                        <td><b>Year:</b></td>
                        <td>dont know</td>
                      </tr>
                      <tr>
                      <td><b>Obtain Marks:</b></td>
                        <td>Pata nahi</td>
                      </tr>
                      <tr>
                        <td><b>Total Marks:</b></td>
                        <td>MP Board</td>
                      </tr>
                      <tr>
                        <td><b>Persentage:</b></td>
                        <td>100%</td>
                      </tr>
                    <tr>
                       
                           
                      </tr>
                     
                    </tbody>
                  </table>
                  
                  
                </div>
              </div>
  </div>
</div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>